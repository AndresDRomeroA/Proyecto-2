import requests
from Clases import Crucero
from Clases import Room
from Clases import Usuario

matriz_S = []
matriz_P = []
matriz_V = []

def registrar(acompanantes, type_of_room, room, crucero):
  '''
  Funcion para registrar a un usuario en la base de datos
  '''
  print(
        '''
        Por favor, ingrese sus datos
        '''
    )  
  nombre = input(
        '''
        Ingrese su nombre completo:
        '''
    ).title()

  while True:
    try:
      cedula = int(input(
        '''
        Ingrese su cedula (unicamente números):  
        '''
            ))
      break
    except:
      print("Valide sus datos")

  while True:
    try:
      edad = int(input(
        '''
        Ingrese su edad:  
        '''
            ))
      break
    except:
      print("Valide sus datos")
  while True:
    try:
      genero = input(
        '''
        Ingrese su genero:    (M/F)
        '''
            ).upper()

      if genero == 'M' or genero == 'F':
        usuario = Usuario(nombre, cedula, edad, genero, acompanantes, type_of_room, room)
        with open("BaseDeDatos.txt", "a+") as bd: #El a+ es por si el archivo no se ha creado entonces se crea
          bd.write("{},{},{},{},{},{}\n".format(nombre, cedula, edad, genero, acompanantes, type_of_room, room))
        print('\tUsuario: ', usuario.nombre, ' registrado correctamente')
        break
      else:
        raise Exeption
    except:
      print("valide sus datos")

  while True:
    try:
      discapacidad = int(input(
          '''
           ¿Posee alguna discapacidad?
         1. Si
         2. No
          '''))

      if discapacidad < 1 or discapacidad > 2:
        raise Exception
      break

    except:
      print("valide sus datos")

  costo = crucero.cost[usuario.type_of_room]
  descuento = 0

  if discapacidad == 1:
    posee_discapacidad = "Si"
    descuento += costo*30/100
  else:
    posee_discapacidad = "No"

  if es_primo(usuario.cedula):
    descuento += costo*10/100
  
  if es_abundante(usuario.cedula):
    descuento += costo*15/100
  
  if usuario.edad > 65:
    if usuario.type_of_room == "simple":
      print("{} ha sido subido a premium".format(usuario.nombre))
  
  impuestos = costo*16/100

  monto_Total = costo + impuestos - descuento

  print(
    '''
    _________________FACTURA_________________
    Nombre: {}
    Cedula: {}
    Edad: {}
    Posee discapacidad: {}
    Habitación seleccionada: {}

    Monto: {} $
    Descuento total: {} $
    Impuestos 16%: {} $
    TOTAL: {} $
    _________________________________________
    '''.format(usuario.nombre, usuario.cedula, usuario.edad, posee_discapacidad, usuario.room, costo, descuento, impuestos, monto_Total))
  
def representacion_Del_Crucero():

  url = 'https://saman-caribbean.vercel.app/api/cruise-ships'
  dic = requests.get(url).json()

    ### Fecha de partida para el Crucero #0
  fecha_hora_0 = dic [0]['departure']
    ### Fecha de partida para el Crucero #1
  fecha_hora_1 = dic [1]['departure']
    ### Fecha de partida para el Crucero #2
  fecha_hora_2 = dic [2]['departure']
    ### Fecha de partida para el Crucero #3
  fecha_hora_3 = dic [3]['departure']

    ### Creacion del crucero 0
  crucero_0 = Crucero(name = dic[0]['name'], route = dic[0]['route'], departure = fecha_hora_0.split('T')[0], cost = dic[0]['cost'], rooms = dic[0]['rooms'], capacity = dic[0]['capacity'], sells = dic[0]['sells'])

    ### Creacion del crucero 1
  crucero_1 = Crucero(name = dic[1]['name'], route = dic[1]['route'], departure = fecha_hora_1.split('T')[0], cost = dic[1]['cost'], rooms = dic[1]['rooms'], capacity = dic[1]['capacity'], sells = dic[1]['sells'])

    ### Creacion del crucero 2
  crucero_2 = Crucero(name = dic[2]['name'], route = dic[2]['route'], departure = fecha_hora_2.split('T')[0], cost = dic[2]['cost'], rooms = dic[2]['rooms'], capacity = dic[2]['capacity'], sells = dic[2]['sells'])

    ### Creacion del crucero 3
  crucero_3 = Crucero(name = dic[3]['name'], route = dic[3]['route'], departure = fecha_hora_3.split('T')[0], cost = dic[3]['cost'], rooms = dic[3]['rooms'], capacity = dic[3]['capacity'], sells = dic[3]['sells'])

  while True:
    try:
      opcion = int(input(
      '''
        Indicar el crucero que desea ver

      1. El Dios de los Mares.
      2. La Reina Isabel.
      3. El Libertador del Océano.
      4. Sabas Nieves.
      5. atras.
      '''))

      opcion -= 1

      if opcion == 0:
        print (crucero_0.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
            ### Crucero_0
              ### Simple Rooms
              cs = crucero_0.rooms['simple'][0]
              rs = crucero_0.rooms['simple'][1]
              total_rs = cs*rs
              
              ### Premium Rooms
              cp = crucero_0.rooms['premium'][0]
              rp = crucero_0.rooms['premium'][1]
              total_rp = cp*rp
              
              ### VIP rooms
              cv = crucero_0.rooms['vip'][0]
              rv = crucero_0.rooms['vip'][1]
              total_rv = cv*rv
              
              while True:
                try:
                  acompanantes = int(input("¿Cuantas personas viajarán juntos?  "))
                  
                  if acompanantes > 8:
                    print ("No tenemos habitaciones para más de 8 personas")
                    raise Exception
                  elif acompanantes < 1:
                    print("El numero de personas debe ser mayor a 0")
                    raise Exception
                  break

                except:
                  print("")

              while True:
                try:
                  opcion2 = int(input(
              '''
                ¿Que tipo de habitación desea?
              
              1. Simple (2 personas).
              2. Premium (4 personas).
              3. VIP. (8 personas)
              4. Regresar.
              '''))

                  if opcion2 == 1:
                    if acompanantes > 2:
                      print("Para las hablitaciones de tipo Simple no se admiten más de 2 personas")
                      raise Exception

                    type_of_room = "simple"
                    type_of_room_0 = "S"

                    while True:
                      try:
                        for i in range(cs):
                          matriz_S.append([0] * rs)
                        for i in matriz_S:
                          print (i) 

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_0)
                    


                  elif opcion2 == 2:
                    if acompanantes > 4:
                      print("Para las hablitaciones de tipo Premium no se admiten más de 4 personas")
                      raise Exception

                    type_of_room = "premium"
                    type_of_room_0 = "P"

                    while True:
                      try:
                        
                        for i in range(cp):
                          matriz_P.append([0] * rp)

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_0)

                  elif opcion2 == 3:
                    if acompanantes > 8:
                      print("Para las hablitaciones de tipo VIP no se admiten más de 8 personas")
                      raise Exception

                    type_of_room = "vip"
                    type_of_room_0 = "V"

                    while True:
                      try:

                        for i in range(cv):
                          matriz_V.append([0] * rv)
                        
                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_0)

                  elif opcion2 == 4:
                    break
                  else:
                    raise Exception

                except:
                  print("Valide sus datos") 

            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 1:
        print (crucero_1.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
            ### Crucero_1
              ### Simple Rooms
              cs = crucero_1.rooms['simple'][0]
              rs = crucero_1.rooms['simple'][1]
              total_rs = cs*rs
              
              ### Premium Rooms
              cp = crucero_1.rooms['premium'][0]
              rp = crucero_1.rooms['premium'][1]
              total_rp = cp*rp
              
              ### VIP rooms
              cv = crucero_1.rooms['vip'][0]
              rv = crucero_1.rooms['vip'][1]
              total_rv = cv*rv
              
              while True:
                try:
                  acompanantes = int(input("¿Cuantas personas viajarán juntos?  "))
                  
                  if acompanantes > 8:
                    print ("No tenemos habitaciones para más de 8 personas")
                    raise Exception
                  elif acompanantes < 1:
                    print("El numero de personas debe ser mayor a 0")
                    raise Exception
                  break

                except:
                  print("")

              while True:
                try:
                  opcion2 = int(input(
              '''
                ¿Que tipo de habitación desea?
              
              1. Simple (2 personas).
              2. Premium (4 personas).
              3. VIP. (8 personas)
              4. Regresar.
              '''))

                  if opcion2 == 1:
                    if acompanantes > 2:
                      print("Para las hablitaciones de tipo Simple no se admiten más de 2 personas")
                      raise Exception

                    type_of_room = "simple"
                    type_of_room_0 = "S"

                    while True:
                      try:
                        for i in range(cs):
                          matriz_S.append([0] * rs)
                        for i in matriz_S:
                          print (i) 

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_1)
                    


                  elif opcion2 == 2:
                    if acompanantes > 4:
                      print("Para las hablitaciones de tipo Premium no se admiten más de 4 personas")
                      raise Exception

                    type_of_room = "premium"
                    type_of_room_0 = "P"

                    while True:
                      try:
                        
                        for i in range(cp):
                          matriz_P.append([0] * rp)

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_1)

                  elif opcion2 == 3:
                    if acompanantes > 8:
                      print("Para las hablitaciones de tipo VIP no se admiten más de 8 personas")
                      raise Exception

                    type_of_room = "vip"
                    type_of_room_0 = "V"

                    while True:
                      try:

                        for i in range(cv):
                          matriz_V.append([0] * rv)
                        
                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_1)

                  elif opcion2 == 4:
                    break
                  else:
                    raise Exception

                except:
                  print("Valide sus datos") 

            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 2:
        print (crucero_2.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
            ### Crucero_2
              ### Simple Rooms
              cs = crucero_2.rooms['simple'][0]
              rs = crucero_2.rooms['simple'][1]
              total_rs = cs*rs
              
              ### Premium Rooms
              cp = crucero_2.rooms['premium'][0]
              rp = crucero_2.rooms['premium'][1]
              total_rp = cp*rp
              
              ### VIP rooms
              cv = crucero_2.rooms['vip'][0]
              rv = crucero_2.rooms['vip'][1]
              total_rv = cv*rv
              
              while True:
                try:
                  acompanantes = int(input("¿Cuantas personas viajarán juntos?  "))
                  
                  if acompanantes > 8:
                    print ("No tenemos habitaciones para más de 8 personas")
                    raise Exception
                  elif acompanantes < 1:
                    print("El numero de personas debe ser mayor a 0")
                    raise Exception
                  break

                except:
                  print("")

              while True:
                try:
                  opcion2 = int(input(
              '''
                ¿Que tipo de habitación desea?
              
              1. Simple (2 personas).
              2. Premium (4 personas).
              3. VIP. (8 personas)
              4. Regresar.
              '''))

                  if opcion2 == 1:
                    if acompanantes > 2:
                      print("Para las hablitaciones de tipo Simple no se admiten más de 2 personas")
                      raise Exception

                    type_of_room = "simple"
                    type_of_room_0 = "S"

                    while True:
                      try:
                        for i in range(cs):
                          matriz_S.append([0] * rs)
                        for i in matriz_S:
                          print (i) 

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_2)
                    


                  elif opcion2 == 2:
                    if acompanantes > 4:
                      print("Para las hablitaciones de tipo Premium no se admiten más de 4 personas")
                      raise Exception

                    type_of_room = "premium"
                    type_of_room_0 = "P"

                    while True:
                      try:
                        
                        for i in range(cp):
                          matriz_P.append([0] * rp)

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_2)

                  elif opcion2 == 3:
                    if acompanantes > 8:
                      print("Para las hablitaciones de tipo VIP no se admiten más de 8 personas")
                      raise Exception

                    type_of_room = "vip"
                    type_of_room_0 = "V"

                    while True:
                      try:

                        for i in range(cv):
                          matriz_V.append([0] * rv)
                        
                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_2)

                  elif opcion2 == 4:
                    break
                  else:
                    raise Exception

                except:
                  print("Valide sus datos") 

            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 3:
        print (crucero_3.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
            ### crucero_3
              ### Simple Rooms
              cs = crucero_3.rooms['simple'][0]
              rs = crucero_3.rooms['simple'][1]
              total_rs = cs*rs
              
              ### Premium Rooms
              cp = crucero_3.rooms['premium'][0]
              rp = crucero_3.rooms['premium'][1]
              total_rp = cp*rp
              
              ### VIP rooms
              cv = crucero_3.rooms['vip'][0]
              rv = crucero_3.rooms['vip'][1]
              total_rv = cv*rv
              
              while True:
                try:
                  acompanantes = int(input("¿Cuantas personas viajarán juntos?  "))
                  
                  if acompanantes > 8:
                    print ("No tenemos habitaciones para más de 8 personas")
                    raise Exception
                  elif acompanantes < 1:
                    print("El numero de personas debe ser mayor a 0")
                    raise Exception
                  break

                except:
                  print("")

              while True:
                try:
                  opcion2 = int(input(
              '''
                ¿Que tipo de habitación desea?
              
              1. Simple (2 personas).
              2. Premium (4 personas).
              3. VIP. (8 personas)
              4. Regresar.
              '''))

                  if opcion2 == 1:
                    if acompanantes > 2:
                      print("Para las hablitaciones de tipo Simple no se admiten más de 2 personas")
                      raise Exception

                    type_of_room = "simple"
                    type_of_room_0 = "S"

                    while True:
                      try:
                        for i in range(cs):
                          matriz_S.append([0] * rs)
                        for i in matriz_S:
                          print (i) 

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_3)
                    


                  elif opcion2 == 2:
                    if acompanantes > 4:
                      print("Para las hablitaciones de tipo Premium no se admiten más de 4 personas")
                      raise Exception

                    type_of_room = "premium"
                    type_of_room_0 = "P"

                    while True:
                      try:
                        
                        for i in range(cp):
                          matriz_P.append([0] * rp)

                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_3)

                  elif opcion2 == 3:
                    if acompanantes > 8:
                      print("Para las hablitaciones de tipo VIP no se admiten más de 8 personas")
                      raise Exception

                    type_of_room = "vip"
                    type_of_room_0 = "V"

                    while True:
                      try:

                        for i in range(cv):
                          matriz_V.append([0] * rv)
                        
                        corridor_n = int(input('Indicar el corredor en el que quiere estar:  (va del 0 al 3)  '))
                    
                        if corridor_n == 0:
                          corridor = "A"
                        elif corridor_n == 1:
                          corridor = "B"
                        elif corridor_n == 2:
                          corridor = "C"
                        elif corridor_n == 3:
                          corridor = "D"
                        else:
                          raise Exception

                        room_n = int(input('Indicar la habitacion en la que quiere estar:   (va del 0 al 9)   '))

                        if room_n < 0 and room_n > 9:
                          raise Exception
                        break

                      except:
                        print("Valide sus datos")

                    for j in range(len(matriz_S)):
                      for k in range(len(matriz_S[j])):

                        matriz_S[corridor_n][room_n] = 1

                    room = type_of_room_0 + corridor + str(room_n)

                    registrar(acompanantes, type_of_room, room, crucero_3)

                  elif opcion2 == 4:
                    break
                  else:
                    raise Exception

                except:
                  print("Valide sus datos") 

            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 4:
        break

      else:
        raise Exception

    except:
      print(' Valide sus datos')

def representacion_destino():

  url = 'https://saman-caribbean.vercel.app/api/cruise-ships'
  dic = requests.get(url).json()

    ### Fecha de partida para el Crucero #0
  fecha_hora_0 = dic [0]['departure']
    ### Fecha de partida para el Crucero #1
  fecha_hora_1 = dic [1]['departure']
    ### Fecha de partida para el Crucero #2
  fecha_hora_2 = dic [2]['departure']
    ### Fecha de partida para el Crucero #3
  fecha_hora_3 = dic [3]['departure']

    ### Creacion del crucero 0
  crucero_0 = Crucero(name = dic[0]['name'], route = dic[0]['route'], departure = fecha_hora_0.split('T')[0], cost = dic[0]['cost'], rooms = dic[0]['rooms'], capacity = dic[0]['capacity'], sells = dic[0]['sells'])

    ### Creacion del crucero 1
  crucero_1 = Crucero(name = dic[1]['name'], route = dic[1]['route'], departure = fecha_hora_1.split('T')[0], cost = dic[1]['cost'], rooms = dic[1]['rooms'], capacity = dic[1]['capacity'], sells = dic[1]['sells'])

    ### Creacion del crucero 2
  crucero_2 = Crucero(name = dic[2]['name'], route = dic[2]['route'], departure = fecha_hora_2.split('T')[0], cost = dic[2]['cost'], rooms = dic[2]['rooms'], capacity = dic[2]['capacity'], sells = dic[2]['sells'])

    ### Creacion del crucero 3
  crucero_3 = Crucero(name = dic[3]['name'], route = dic[3]['route'], departure = fecha_hora_3.split('T')[0], cost = dic[3]['cost'], rooms = dic[3]['rooms'], capacity = dic[3]['capacity'], sells = dic[3]['sells'])
  
      
  while True:
    try:    
      opcion = int(input(
      '''
        ¿Indicar el destino de su preferencia?

      1. {}
      2. {}
      3. {}
      4. {}
      5. Atras
      '''.format(crucero_0.route, crucero_1.route, crucero_2.route, crucero_3.route)))

      opcion -= 1

      if opcion == 0:
        print (crucero_0.crucero_sin_sells())
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
            ### Crucero_0
              ### Simple Rooms
              cs = crucero_0.rooms['simple'][0]
              rs = crucero_0.rooms['simple'][1]
              total_rs = cs*rs
              
              ### Premium Rooms
              cp = crucero_0.rooms['premium'][0]
              rp = crucero_0.rooms['premium'][1]
              total_rp = cp*rp
              
              ### VIP rooms
              cv = crucero_0.rooms['vip'][0]
              rv = crucero_0.rooms['vip'][1]
              total_rv = cv*rv
              
              while True:
                try:
                  opcion2 = int(input(
              '''
                ¿Que tipo de habitación desea?
              
              1. Simple.
              2. Premium.
              3. VIP.
              4. Regresar.
              '''))

                  if opcion2 == 1:
                    pass

                  elif opcion2 == 2:
                    pass

                  elif opcion2 == 3:
                    pass

                  elif opcion2 == 4:
                    break
                  else:
                    raise Exception

                except:
                  print("Valide sus datos") 

            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 1:
        print (crucero_1.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
              print('hola')
            
            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 2:
        print (crucero_2.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
              print('hola')
            
            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 3:
        print (crucero_3.crucero_sin_sells())
        
        while True:
          try:
            opcion1 = int(input(
              '''
                ¿Desea proseguir?
              
              1. Si.
              2. Volver atrás.
              '''))

            if opcion1 == 1:
              print('hola')
            
            elif opcion1 == 2:
              break

            else:
              raise Exception
            
          except:
            print('Valide sus datos')

      elif opcion == 4:
        break

      else:
        raise Exception

    except:
      print("Valide sus datos")
  
def es_primo(cedula):
  contador = 0
  verificar= False
  for i in range(1,cedula+1):
    if (cedula% i)==0:
       contador = contador + 1
    if contador >= 3:
        verificar=True
        break

  if contador==2 or verificar==False:
    return True
  else:
    return False
  
def es_abundante(cedula):
  contador =  1
  suma = 0

  while (contador<cedula):
    if (cedula%contador==0):
      suma+=contador
    contador = contador + 1
  if (suma>(cedula)):
    return True
  else:
    return False

def main():
  while True:
    try:
      opcion0 = int(input(
      '''
        ¿Desea comprar su boleto en base a destino o en base al crucero?

      1. Destino (NO FUNCIONA).
      2. Crucero.
      3. Salir.
      '''))

      if opcion0 == 1:
        representacion_destino()


      elif opcion0 == 2:
        representacion_Del_Crucero()


      elif opcion0 == 3:
        break


      else:
        raise Exception
    
    except:
      print("Valide sus datos")

main()
