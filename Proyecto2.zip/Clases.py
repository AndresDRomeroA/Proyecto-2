class Crucero:

  ###Clase que representa a Crucero
  
  def __init__(self, name, route, departure, cost, rooms, capacity, sells):
      ###Atributos de la clase Crucero

      self.name = name
      self.route = route
      self.departure = departure
      self.cost = cost
      self.rooms = rooms
      self.capacity = capacity
      self.sells = sells

    ### Funcion que retorna todos sus parametros
  def __str__(self):
    return (
    '''
    _____________________________________________________________________________________
    Name: {}
    Route: {}
    Departure: {}
    Cost: {}
    Corridor, Rooms per type: {}
    Capacity per room: {}
    Sells: {}
    _____________________________________________________________________________________
    '''.format(self.name, self.route, self.departure, self.cost, self.rooms, self.capacity, self.sells))

    ### Funcion que retorna todos sus atributos sin "Sells"
  def crucero_sin_sells(self):
    return (
    '''
    _____________________________________________________________________________________
    Name: {}
    Route: {}
    Departure: {}
    Cost: {}
    Corridor, Rooms per type: {}
    Capacity per room: {}
    _____________________________________________________________________________________
    '''.format(self.name, self.route, self.departure, self.cost, self.rooms, self.capacity))


class Room:


  ###Clase que representa a Room
  
  def __init__(self, corridor, n_room, capacity, reference, type_of_room, occupancy):
      ###Atributos de la clase Room

      self.corridor = corridor
      self.n_room = n_room
      self.capacity = capacity 
      self.reference = reference
      self.type_of_room = type_of_room
      self.occupancy = occupancy

    ### Funcion que retorna todos sus parametros
  def __str__(self):
    return (
    '''
    ________________________________
    Corridor: {}
    N° Room: {}
    Capacity: {}
    References: {}
    Type of Room: {}
    occupancy: {}
    ________________________________
    '''.format(self.corridor, self.n_room, self.capacity, self.reference, self.type_of_room, self.occupancy))


class Usuario:
    def __init__(self, nombre,cedula, edad, genero, acompanantes, type_of_room, room):
        self.nombre = nombre
        self.cedula = cedula
        self.edad = edad
        self.genero = genero
        self.acompanantes = acompanantes
        self.type_of_room = type_of_room
        self.room = room

    def __str__(self):
        return ('''
    ________________________________
    Nombre: {}
    Cedula: {}
    edad: {}
    genero: {}
    acompañantes: {}
    tipo de habitacion: {}
    habitacion: {}
    ________________________________
    '''.format(self.nombre,self.cedula, self.edad, self.genero, self.acompanantes, self.type_of_room, self.room))